
<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html>
<head>
<title>About Us - vimax in pakistan - As Seen On Tv Pakistan Products online shopping in pakistan-shoppakistan</title>
<!--/tags -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>About Us - vimax in pakistan - As Seen On Tv Pakistan Products online shopping in pakistan-shoppakistan</title>
<meta name="description" content="vimax in pakistan,About Us, As Seen On Tv Pakistan Products, Sandhi Sudha oil, Viagra Tablet, Ab Rocket Twister, Instyler Price, Spy Camera pen, Sandhi Sudha Plus, vimax Pakistan" />
<meta name="keywords" content="viamax pills, viamax in pakistan, ebay store in pakistan, derma seta spa, tummy fit oil, dr ayurveda power prash, shakti prash in pakistan, instyler, instyler pakistan, H2o Mop X5, x5 steam mop in pakistan, x5 steam cleaner, Hair Building Fiber, aire bra pakistan, 5 in 1 sofa bed in pakistan, velform sauna belt in pakistan, nicer dicer Plus in pakistan, salad chef in pakisan, wizzit hair removal, handy massager in pakistan, foot massager machine, ab rocket twister price, ab rocket twister in pakistan, magic pen camera in pakistan, viagra tablets pakistan, viagra in pakistan, breast enlargment cream in pakistan, step up height increaser in pakistan, lady secret cream in pakistan, easy sew machine, easy slim tea, fitness pump in pakistan, hgp hair grow pro, fair look cream in pakistan, no addiction powder in pakistan, perfact shapper in pakistan, as seen on tv products in pakistan, air lounge in pakisan, sandhi sudha in pakistan, sandhi sudha oil, Sandhi Sudha Plus, Sandhi Sudha Plus in Pakistan" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--//tags -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/team.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/font-awesome.css" rel="stylesheet"> 
<script language="JavaScript" type="text/JavaScript">
	function fetchSubcats() {
var val;		
val = $('#val').val();
var my_items= new Array();
my_items["EcoSlim"]=4499;
my_items["SlimmingCapsule"]=4500;
my_items["Air Lounge"]=8000;
my_items["Slim n Lift"]=1300;
my_items["Slim n Lift Men"]=2000;
my_items["Slender Shaper"]=5000;
my_items["Dr Slimming Tea"]=2000;
my_items["Easy Slimming Tea"]=2000;
my_items["Sauna Belt"]=2000;
my_items["Sauna Massage Velform"]=3000;
my_items["Sauna 2in1"]=3000;
my_items["Nicer Dicer"]=2000;
my_items["Nicer Dicer Plus"]=2500;
my_items["Hair Color Shampoo"]=2000;
my_items["Teeth Whitener"]=2000;
my_items["3in1 Juicer"]=5000;
my_items["Steam Iron"]=2000;
my_items["No Addiction"]=3000;
my_items["Voox_DD_Cream"]=3000;
my_items["Handy Massager"]=2000;
my_items["Ab Rocket"]=3500;
my_items["Ab Rocket Twister"]=5000;
my_items["Magic Pen 2Gb"]=3500;
my_items["Magic Pen 4Gb"]=4500;
my_items["English Guru"]=2000;
my_items["Ionic White"]=2000;
my_items["Soft Fair"]=1000;
my_items["Men Power"]=2000;
my_items["Breast Enlargement"]=2000;
my_items["Lady Secret Cream"]=2000;
my_items["Hair Dryer"]=2000;
my_items["Veet For Men"]=1999;
my_items["Sandhi Sudha"]=2950;
my_items["Sandhi Sudha Plus"]=3000;
my_items["Derma Seta"]=2000;
my_items["Epilator"]=2000;
my_items["Smoothie Maker"]=4000;
my_items["Fitness Pump"]=6000;
my_items["hair Styler"]=3500;
my_items["Slap Chop"]=2000;
my_items["Perfect Shaper"]=2000;
my_items["Electric Beauty Threader"]=2000;
my_items["Tummy Fit"]=2500;
my_items["Pops A Dent"]=2500;
my_items["Aire Bra"]=3000;
my_items["Ahh Bra"]=3000;
my_items["Meta Slim"]=2950;
my_items["Hair Building Fiber"]=2500;
my_items["H20 Mop X5"]=8000;
my_items["Power Prash"]=2950;
my_items["Step Up"]=2999;
my_items["Vimax Pills"]=3000;
my_items["Vimax"]=3000;
my_items["Vimax Detox"]=2499;
my_items["Raspberry Ketone"]=2499;
my_items["Hot Shaper"]=2999;
my_items["Roti Maker"]=4999;
my_items["Ab ZoneFlex"]=7000;
my_items["Caboki Hair Fiber"]=3000;
my_items["Shakti Prash"]=3499;
my_items["Ultra Wizzit"]=1999;
my_items["Hair Grow Pro"]=3399;
my_items["Slim Pro 24"]=3399;




var item_price	=	my_items[val]; 
var defult	=	200;
var Order_Total	=	defult+item_price;
$("#mainsubcat").html("<strong >Product Cost: Rs</strong>. "+item_price+"<br/><strong>Shipping Total:Rs</strong>. "+defult+"<br/><strong>Order Total: Rs</strong>."+Order_Total);
	}
</script>


<!-- Menu End -->
<!-- Start Alexa Certify Javascript -->
<script type="text/javascript">
_atrk_opts = { atrk_acct:"/sOtl1agWBr170", domain:"shoppakistan.com.pk",dynamic: true};
(function() { var as = document.createElement('script'); as.type = 'text/javascript'; as.async = true; as.src = "https://d31qbv1cthcecs.cloudfront.net/atrk.js"; var s = document.getElementsByTagName('script')[0];s.parentNode.insertBefore(as, s); })();
</script>
<!-- //for bootstrap working -->
<link href="//fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800" rel="stylesheet">
<link href='//fonts.googleapis.com/css?family=Lato:400,100,100italic,300,300italic,400italic,700,900,900italic,700italic' rel='stylesheet' type='text/css'>
</head>
<body>
<!-- header -->
<div class="header" id="home">
	<div class="container">
		<ul>
		    <li> <a href="#" data-toggle="modal" data-target="#myModal"><i class="fa fa-unlock-alt" aria-hidden="true"></i>Contact Us </a></li>
			<li> <a href="#" data-toggle="modal" data-target="#myModal2"><i class="fa fa-pencil-square-o" aria-hidden="true"></i>Policy</a></li>
			<li> <a href="#" data-toggle="modal" data-target="#myModal2"><i class="fa fa-pencil-square-o" aria-hidden="true"></i>Payment</a></li>
			<li><i class="fa fa-phone" aria-hidden="true"></i> Call :0300-7986016</li>
			
			
		</ul>
	</div>
</div>
<!-- //header -->
<!-- header-bot -->
<div class="header-bot">
	<div class="header-bot_inner_wthreeinfo_header_mid">
		<!--<div class="col-md-4 header-middle">
			<form action="#" method="post">
					<input type="search" name="search" placeholder="Search here..." required="">
					<input type="submit" value=" ">
				<div class="clearfix"></div>
			</form>
		</div>-->
		<!-- header-bot -->
			<div class="col-md-4 logo_agile">
				<h1><a href="index.html"><span>S</span>hop Pakistan</a></h1>
			</div>
        <!-- header-bot -->
		<div class="col-md-4 agileits-social top_content">
						<ul class="social-nav model-3d-0 footer-social w3_agile_social">
						                                   <li class="share">Share On : </li>
															<li><a href="#" class="facebook">
																  <div class="front"><i class="fa fa-facebook" aria-hidden="true"></i></div>
																  <div class="back"><i class="fa fa-facebook" aria-hidden="true"></i></div></a></li>
															<li><a href="#" class="twitter"> 
																  <div class="front"><i class="fa fa-twitter" aria-hidden="true"></i></div>
																  <div class="back"><i class="fa fa-twitter" aria-hidden="true"></i></div></a></li>
															<li><a href="#" class="instagram">
																  <div class="front"><i class="fa fa-instagram" aria-hidden="true"></i></div>
																  <div class="back"><i class="fa fa-instagram" aria-hidden="true"></i></div></a></li>
															<li><a href="#" class="pinterest">
																  <div class="front"><i class="fa fa-linkedin" aria-hidden="true"></i></div>
																  <div class="back"><i class="fa fa-linkedin" aria-hidden="true"></i></div></a></li>
														</ul>



		</div>
		<div class="clearfix"></div>
	</div>
</div>
<!-- //header-bot -->
<!-- banner -->
<div class="ban-top">
	<div class="container">
		<div class="top_nav_left">
			<nav class="navbar navbar-default">
			  <div class="container-fluid">
				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header">
				  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				  </button>
				</div>
				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse menu--shylock" id="bs-example-navbar-collapse-1">
				  <ul class="nav navbar-nav menu__list">
					<li class="active menu__item menu__item--current"><a class="menu__link" href="index.html">Home <span class="sr-only">(current)</span></a></li>
					<li class=" menu__item"><a class="menu__link" href="about.html">About</a></li>
					<li class="dropdown menu__item">
						<a href="#" class="dropdown-toggle menu__link" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Beauty Products <span class="caret"></span></a>
							<ul class="dropdown-menu multi-column columns-3">
								<div class="agile_inner_drop_nav_info">
									<div class="col-sm-6 multi-gd-img1 multi-gd-text ">
										<a href="mens.html"><img src="images/beauty-online-store.png" alt="beauty Online Store"></a>
									</div>
									<div class="col-sm-3 multi-gd-img">
										<ul class="multi-column-dropdown">
											<li><a href="mens.html">Vimax Detox</a></li>
											<li><a href="mens.html">Voox DD Cream</a></li>
											<li><a href="mens.html">Aire Bra</a></li>
											<li><a href="mens.html">Hair Straighter</a></li>
											<li><a href="mens.html">Breast Enlargment</a></li>
											<li><a href="mens.html">Caboki</a></li>
											<li><a href="mens.html">Fair Look</a></li>
										</ul>
									</div>
									<div class="col-sm-3 multi-gd-img">
										<ul class="multi-column-dropdown">
											<li><a href="mens.html">Electric Threader</a></li>
											<li><a href="mens.html">Ultra Wizzit</a></li>
											<li><a href="mens.html">Derma Seta</a></li>
											<li><a href="mens.html">Hot Shaper</a></li>
											<li><a href="mens.html">Hair Dryer</a></li>
											<li><a href="mens.html">Perfect Shaper</a></li>
											<li><a href="mens.html">Slim N Lift Men</a></li>
										</ul>
									</div>
									<div class="clearfix"></div>
								</div>
							</ul>
					</li>
					<li class="dropdown menu__item">
						<a href="#" class="dropdown-toggle menu__link" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Fitness Products <span class="caret"></span></a>
							<ul class="dropdown-menu multi-column columns-3">
								<div class="agile_inner_drop_nav_info">
									<div class="col-sm-3 multi-gd-img">
										<ul class="multi-column-dropdown">
											<li><a href="womens.html">Ab Zone Flex</a></li>
											<li><a href="womens.html">Fitness Pump</a></li>
											<li><a href="womens.html">Tummy Tuck</a></li>
											<li><a href="womens.html">Body Slimmer</a></li>
											<li><a href="womens.html">Body Massager</a></li>
											<li><a href="womens.html">Raspberry Ketones</a></li>
											<li><a href="womens.html">Sauna Belt</a></li>
										</ul>
									</div>
									<div class="col-sm-3 multi-gd-img">
										<ul class="multi-column-dropdown">
											<li><a href="womens.html">Sauna Belt 2 In 1</a></li>
											<li><a href="womens.html">Slender Shaper</a></li>
											<li><a href="womens.html">Body Build o Powder</a></li>
											<li><a href="womens.html">Coral Body Slimmer</a></li>
											<li><a href="womens.html">Ab Rocket Twister</a></li>
											<li><a href="womens.html">StemCell</a></li>
											<li><a href="womens.html">Sauna Massage Velform</a></li>
										</ul>
									</div>
									<div class="col-sm-6 multi-gd-img multi-gd-text ">
										<a href="womens.html"><img src="images/fitness-online-store.jpg" alt="fitness online store"/></a>
									</div>
									<div class="clearfix"></div>
								</div>
							</ul>
					</li>
					<li class="menu__item dropdown">
					   <a class="menu__link" href="#" class="dropdown-toggle" data-toggle="dropdown">Men <b class="caret"></b></a>
								<ul class="dropdown-menu agile_short_dropdown">
									<li><a href="icons.html">Viagra Tablets</a></li>
									<li><a href="typography.html">Cialis Tablets</a></li>
								</ul>
					</li>
					<li class=" menu__item"><a class="menu__link" href="contact.html">Blog</a></li>
				  </ul>
				</div>
			  </div>
			</nav>	
		</div>
		<!--<div class="top_nav_right">
			<div class="wthreecartaits wthreecartaits2 cart cart box_1"> 
						<form action="#" method="post" class="last"> 
						<input type="hidden" name="cmd" value="_cart">
						<input type="hidden" name="display" value="1">
						<button class="w3view-cart" type="submit" name="submit" value=""><i class="fa fa-cart-arrow-down" aria-hidden="true"></i></button>
					</form>  
  
						</div>
		</div>-->
		<div class="clearfix"></div>
	</div>
</div>
<!-- //banner-top -->
<!-- Modal1 -->
		<div class="modal fade" id="myModal" tabindex="-1" role="dialog">
			<div class="modal-dialog">
				<!-- Modal content-->
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal">&times;</button>
					</div>
						<div class="modal-body modal-body-sub_agile">
						<div class="col-md-8 modal_body_left modal_body_left1">
						<h3 class="agileinfo_sign">Sign In <span>Now</span></h3>
									<form action="#" method="post">
							<div class="styled-input agile-styled-input-top">
								<input type="text" name="Name" required="">
								<label>Name</label>
								<span></span>
							</div>
							<div class="styled-input">
								<input type="email" name="Email" required=""> 
								<label>Email</label>
								<span></span>
							</div> 
							<input type="submit" value="Sign In">
						</form>
						  <ul class="social-nav model-3d-0 footer-social w3_agile_social top_agile_third">
															<li><a href="#" class="facebook">
																  <div class="front"><i class="fa fa-facebook" aria-hidden="true"></i></div>
																  <div class="back"><i class="fa fa-facebook" aria-hidden="true"></i></div></a></li>
															<li><a href="#" class="twitter"> 
																  <div class="front"><i class="fa fa-twitter" aria-hidden="true"></i></div>
																  <div class="back"><i class="fa fa-twitter" aria-hidden="true"></i></div></a></li>
															<li><a href="#" class="instagram">
																  <div class="front"><i class="fa fa-instagram" aria-hidden="true"></i></div>
																  <div class="back"><i class="fa fa-instagram" aria-hidden="true"></i></div></a></li>
															<li><a href="#" class="pinterest">
																  <div class="front"><i class="fa fa-linkedin" aria-hidden="true"></i></div>
																  <div class="back"><i class="fa fa-linkedin" aria-hidden="true"></i></div></a></li>
														</ul>
														<div class="clearfix"></div>
														<p><a href="#" data-toggle="modal" data-target="#myModal2" > Don't have an account?</a></p>

						</div>
						<div class="col-md-4 modal_body_right modal_body_right1">
							<img src="images/log_pic.jpg" alt=" "/>
						</div>
						<div class="clearfix"></div>
					</div>
				</div>
				<!-- //Modal content-->
			</div>
		</div>
<!-- //Modal1 -->
<!-- Modal2 -->
<link href="css/styles.css" rel="stylesheet" type="text/css" />

		<div class="modal fade" id="myModal2" tabindex="-1" role="dialog">
			<div class="modal-dialog">
				<!-- Modal content-->
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal">&times;</button>
					</div>
						<div class="modal-body modal-body-sub_agile">
						<div class="col-md-8 modal_body_left modal_body_left1">
						<h3 class="agileinfo_sign">Sign Up <span>Now</span></h3>
									<form action="#" method="post">
							<div class="styled-input agile-styled-input-top">
								<input type="text" name="Name" required="">
								<label>Name</label>
								<span></span>
							</div>
							<div class="styled-input">
								<input type="email" name="Email" required=""> 
								<label>Email</label>
								<span></span>
							</div> 
							<div class="styled-input">
								<input type="password" name="password" required=""> 
								<label>Password</label>
								<span></span>
							</div> 
							<div class="styled-input">
								<input type="password" name="Confirm Password" required=""> 
								<label>Confirm Password</label>
								<span></span>
							</div> 
							<input type="submit" value="Sign Up">
						</form>
						  <ul class="social-nav model-3d-0 footer-social w3_agile_social top_agile_third">
															<li><a href="#" class="facebook">
																  <div class="front"><i class="fa fa-facebook" aria-hidden="true"></i></div>
																  <div class="back"><i class="fa fa-facebook" aria-hidden="true"></i></div></a></li>
															<li><a href="#" class="twitter"> 
																  <div class="front"><i class="fa fa-twitter" aria-hidden="true"></i></div>
																  <div class="back"><i class="fa fa-twitter" aria-hidden="true"></i></div></a></li>
															<li><a href="#" class="instagram">
																  <div class="front"><i class="fa fa-instagram" aria-hidden="true"></i></div>
																  <div class="back"><i class="fa fa-instagram" aria-hidden="true"></i></div></a></li>
															<li><a href="#" class="pinterest">
																  <div class="front"><i class="fa fa-linkedin" aria-hidden="true"></i></div>
																  <div class="back"><i class="fa fa-linkedin" aria-hidden="true"></i></div></a></li>
														</ul>
														<div class="clearfix"></div>
														<p><a href="#">By clicking register, I agree to your terms</a></p>

						</div>
						<div class="col-md-4 modal_body_right modal_body_right1">
							<img src="images/log_pic.jpg" alt=" "/>
						</div>
						<div class="clearfix"></div>
					</div>
				</div>
				<!-- //Modal content-->
			</div>
		</div>
<!-- //Modal2 -->
<!-- /banner_bottom_agile_info -->
<div class="page-head_agile_info_w3l">
		<div class="container">
			<h3>About <span>Us </span></h3>
			<!--/w3_short-->
				 <div class="services-breadcrumb">
						<div class="agile_inner_breadcrumb">

						   <ul class="w3_short">
								<li><a href="index.html">Home</a><i>|</i></li>
								<li>About</li>
							</ul>
						 </div>
				</div>
	   <!--//w3_short-->
	</div>
</div>
<!-- /banner_bottom_agile_info -->
    <div class="banner_bottom_agile_info">
	    <div class="container">
			<div class="agile_ab_w3ls_info">
				<div class="col-md-6 ab_pic_w3ls">
<h1 class="h2_20" style="font-weight:bold;">Place Online Order Here</h1>
 <tr>
         <td>&nbsp;</td>
    </tr>
	    <tr>
         <td>&nbsp;</td>
	    </tr>
        </table></td>
        <td width="30"></td>
        <td width="750" align="left" valign="top"><table style="margin-left: 120px;" width="750" border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td width="410" style="background-color: #024f6d;
    padding-right: 90px;
    padding-left: 20px;
    padding-bottom: 10px;
    padding-top: 10px;" align="center" valign="top"><form name="order-form" action="process.php" method="post" onSubmit="return validateFormOnSubmit(this)">
            <table width="400" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td width="180" height="35" align="left" valign="middle" class="text13g"><span class="red">*</span> Full Name:</td>
                <td width="220" height="35" align="left" valign="middle"><input required="required" style="height: 30px;" type="text" name="txtName" class="textfield" /></td>
              </tr>
              <tr>
                <td width="180"></td>
                <td width="220" class="errorMsg" id="Name" align="left"></td>
              </tr>
              <tr>
                <td width="180" height="35" align="left" valign="middle" class="text13g"><span class="red">*</span> Delivery Address:</td>
                <td width="220" height="35" align="left" valign="middle"><input required="required" style="height: 30px;" type="text" name="txtAddress" class="textfield" /></td>
              </tr>
              <tr>
                <td width="180"></td>
                <td width="220" id="Delivery Address" class="errorMsg" align="left"></td>
              </tr>
              <tr>
                <td width="180" height="35" align="left" valign="middle" class="text13g"><span class="red">*</span> City:</td>
                <td width="220" height="35" align="left" valign="middle"><input required="required" style="height: 30px;" type="text" name="txtCity" class="textfield" /></td>
              </tr>
              <tr>
                <td width="180"></td>
                <td width="220" id="City" class="errorMsg" align="left"></td>
              </tr>
              <tr>
                <td width="180" height="35" align="left" valign="middle" class="text13g">Country:</td>
                <td width="220" height="35" align="left" valign="middle">
                <select name="country" class="list" style="width:202px; height:30px; font-family:Arial, Helvetica, sans-serif; font-size:12px; padding:5px;">
				<option>Afghanistan</option>
				<option>Ã…land Islands</option>
				<option>Albania</option>
				<option>Algeria</option>
				<option>American Samoa</option>
				<option>Andorra</option>
				<option>Angola</option>
				<option>Anguilla</option>
				<option>Antarctica</option>
				<option>Antigua and Barbuda</option>
				<option>Argentina</option>
				<option>Armenia</option>
				<option>Aruba</option>
				<option>Australia</option>
				<option>Austria</option>
				<option>Azerbaijan</option>
				<option>Bahamas</option>
				<option>Bahrain</option>
				<option>Bangladesh</option>
				<option>Barbados</option>
				<option>Belarus</option>
				<option>Belgium</option>
				<option>Belize</option>
				<option>Benin</option>
				<option>Bermuda</option>
				<option>Bhutan</option>
				<option>Bolivia</option>
				<option>Bosnia and Herzegovina</option>
				<option>Botswana</option>
				<option>Bouvet Island</option>
				<option>Brazil</option>
				<option>British Indian Ocean territory</option>
				<option>Brunei Darussalam</option>
				<option>Bulgaria</option>
				<option>Burkina Faso</option>
				<option>Burundi</option>
				<option>Cambodia</option>
				<option>Cameroon</option>
				<option>Canada</option>
				<option>Cape Verde</option>
				<option>Cayman Islands</option>
				<option>Central African Republic</option>
				<option>Chad</option>
				<option>Chile</option>
				<option>China</option>
				<option>Christmas Island</option>
				<option>Cocos (Keeling) Islands</option>
				<option>Colombia</option>
				<option>Comoros</option>
				<option>Congo</option>
				<option>Congo, Democratic Republic</option>
				<option>Cook Islands</option>
				<option>Costa Rica</option>
				<option>CÃ´te d'Ivoire (Ivory Coast)</option>
				<option>Croatia (Hrvatska)</option>
				<option>Cuba</option>
				<option>Cyprus</option>
				<option>Czech Republic</option>
				<option>Denmark</option>
				<option>Djibouti</option>
				<option>Dominica</option>
				<option>Dominican Republic</option>
				<option>East Timor</option>
				<option>Ecuador</option>
				<option>Egypt</option>
				<option>El Salvador</option>
				<option>Equatorial Guinea</option>
				<option>Eritrea</option>
				<option>Estonia</option>
				<option>Ethiopia</option>
				<option>Falkland Islands</option>
				<option>Faroe Islands</option>
				<option>Fiji</option>
				<option>Finland</option>
				<option>France</option>
				<option>French Guiana</option>
				<option>French Polynesia</option>
				<option>French Southern Territories</option>
				<option>Gabon</option>
				<option>Gambia</option>
				<option>Georgia</option>
				<option>Germany</option>
				<option>Ghana</option>
				<option>Gibraltar</option>
				<option>Greece</option>
				<option>Greenland</option>
				<option>Grenada</option>
				<option>Guadeloupe</option>
				<option>Guam</option>
				<option>Guatemala</option>
				<option>Guinea</option>
				<option>Guinea-Bissau</option>
				<option>Guyana</option>
				<option>Haiti</option>
				<option>Heard and McDonald Islands</option>
				<option>Honduras</option>
				<option>Hong Kong</option>
				<option>Hungary</option>
				<option>Iceland</option>
				<option>India</option>
				<option>Indonesia</option>
				<option>Iran</option>
				<option>Iraq</option>
				<option>Ireland</option>
				<option>Israel</option>
				<option>Italy</option>
				<option>Jamaica</option>
				<option>Japan</option>
				<option>Jordan</option>
				<option>Kazakhstan</option>
				<option>Kenya</option>
				<option>Kiribati</option>
				<option>Korea (north)</option>
				<option>Korea (south)</option>
				<option>Kuwait</option>
				<option>Kyrgyzstan</option>
				<option>Lao People's Democratic Republic</option>
				<option>Latvia</option>
				<option>Lebanon</option>
				<option>Lesotho</option>
				<option>Liberia</option>
				<option>Libyan Arab Jamahiriya</option>
				<option>Liechtenstein</option>
				<option>Lithuania</option>
				<option>Luxembourg</option>
				<option>Macao</option>
				<option>Macedonia, Former Yugoslav Republic Of</option>
				<option>Madagascar</option>
				<option>Malawi</option>
				<option>Malaysia</option>
				<option>Maldives</option>
				<option>Mali</option>
				<option>Malta</option>
				<option>Marshall Islands</option>
				<option>Martinique</option>
				<option>Mauritania</option>
				<option>Mauritius</option>
				<option>Mayotte</option>
				<option>Mexico</option>
				<option>Micronesia</option>
				<option>Moldova</option>
				<option>Monaco</option>
				<option>Mongolia</option>
				<option>Montenegro</option>
				<option>Montserrat</option>
				<option>Morocco</option>
				<option>Mozambique</option>
				<option>Myanmar</option>
				<option>Namibia</option>
				<option>Nauru</option>
				<option>Nepal</option>
				<option>Netherlands</option>
				<option>Netherlands Antilles</option>
				<option>New Caledonia</option>
				<option>New Zealand</option>
				<option>Nicaragua</option>
				<option>Niger</option>
				<option>Nigeria</option>
				<option>Niue</option>
				<option>Norfolk Island</option>
				<option>Northern Mariana Islands</option>
				<option>Norway</option>
				<option>Oman</option>
				<option selected>Pakistan</option>
				<option>Palau</option>
				<option>Palestinian Territories</option>
				<option>Panama</option>
				<option>Papua New Guinea</option>
				<option>Paraguay</option>
				<option>Peru</option>
				<option>Philippines</option>
				<option>Pitcairn</option>
				<option>Poland</option>
				<option>Portugal</option>
				<option>Puerto Rico</option>
				<option>Qatar</option>
				<option>RÃ©union</option>
				<option>Romania</option>
				<option>Russian Federation</option>
				<option>Rwanda</option>
				<option>Saint Helena</option>
				<option>Saint Kitts and Nevis</option>
				<option>Saint Lucia</option>
				<option>Saint Pierre and Miquelon</option>
				<option>Saint Vincent and the Grenadines</option>
				<option>Samoa</option>
				<option>San Marino</option>
				<option>Sao Tome and Principe</option>
				<option>Saudi Arabia</option>
				<option>Senegal</option>
				<option>Serbia</option>
				<option>Seychelles</option>
				<option>Sierra Leone</option>
				<option>Singapore</option>
				<option>Slovakia</option>
				<option>Slovenia</option>
				<option>Solomon Islands</option>
				<option>Somalia</option>
				<option>South Africa</option>
				<option>South Georgia and the South Sandwich Islands</option>
				<option>Spain</option>
				<option>Sri Lanka</option>
				<option>Sudan</option>
				<option>Suriname</option>
				<option>Svalbard and Jan Mayen Islands</option>
				<option>Swaziland</option>
				<option>Sweden</option>
				<option>Switzerland</option>
				<option>Syria</option>
				<option>Taiwan</option>
				<option>Tajikistan</option>
				<option>Tanzania</option>
				<option>Thailand</option>
				<option>Togo</option>
				<option>Tokelau</option>
				<option>Tonga</option>
				<option>Trinidad and Tobago</option>
				<option>Tunisia</option>
				<option>Turkey</option>
				<option>Turkmenistan</option>
				<option>Turks and Caicos Islands</option>
				<option>Tuvalu</option>
				<option>Uganda</option>
				<option>Ukraine</option>
				<option>United Arab Emirates</option>
				<option>United Kingdom</option>
				<option>United States of America</option>
				<option>Uruguay</option>
				<option>Uzbekistan</option>
				<option>Vanuatu</option>
				<option>Vatican City</option>
				<option>Venezuela</option>
				<option>Vietnam</option>
				<option>Virgin Islands (British)</option>
				<option>Virgin Islands (US)</option>
				<option>Wallis and Futuna Islands</option>
				<option>Western Sahara</option>
				<option>Yemen</option>
				<option>Zaire</option>
				<option>Zambia</option>
				<option>Zimbabwe</option>
				</select>                </td>
              </tr>
              <tr>
                <td width="180">&nbsp;</td>
                <td width="220">&nbsp;</td>
              </tr>
              <tr>
                <td width="180" height="35" align="left" valign="middle" class="text13g"><span class="red">*</span> Contact 1:</td>
                <td width="220" height="35" align="left" valign="middle"><input required="required" style="height: 30px;" type="text" name="txtMobile" class="textfield" /></td>
              </tr>
              <tr>
                <td width="180"></td>
                <td width="220" id="Mobile Number" class="errorMsg" align="left"></td>
              </tr>
              <tr align="center" valign="middle">
                <td width="180" height="35" align="left" class="text13g">Contact 2:</td>
                <td width="220" height="35" align="left"><input style="height: 30px;" type="text" name="txtMobile2" class="textfield" /></td>
              </tr>
              <tr>
                <td width="180"></td>
                <td width="220"></td>
              </tr>
              <tr>
                <td width="180" height="35" align="left" valign="middle" class="text13g"><span class="red">*</span> Email Address:</td>
                <td width="220" height="35" align="left" valign="middle"><input required="required" style="height: 30px;" type="text" name="txtEmail" class="textfield" /></td>
              </tr>
              <tr>
                <td width="180"></td>
                <td width="220" id="Email" class="errorMsg" align="left"></td>
              </tr>
              <tr>
                <td width="180" height="35" align="left" valign="middle" class="text13g">Select Your Product</td>
                <td width="220" height="35" align="left" valign="middle">
                	<select name="product" class="list" onchange="fetchSubcats();" id="val" style="width:203px; height:30px; font-family:Arial, Helvetica, sans-serif; font-size:12px; padding:5px;">
					<option selected></option>
                    <option>Air Lounge</option>    
                    <option>Slim n Lift</option>
					<option>Slim n Lift Men</option>
 					<option>Sandhi Sudha</option>
					<option>Sandhi Sudha Plus</option>
					<option>Hair Color Shampoo</option>
                    <option>Teeth Whitener</option>
 					<option>Aire Bra</option>
					<option>Ahh Bra</option>
					<option>Derma Seta</option>
                    <option>Slender Shaper</option>
           		    <option>Dr Slimming Tea</option>
                    <option>Easy Slimming Tea</option>
                    <option>No Addiction</option>
                    <option>Sauna Belt</option>
					<option>Fitness Pump</option>
					<option>Sauna Massage Velform</option>
                    <option>Sauna 2in1</option>
                    <option>Nicer Dicer</option>
					<option>Nicer Dicer Plus</option>
                    <option>3in1 Juicer</option>
                    <option>Steam Iron</option>
					<option>Meta Slim</option>
                    <option>Hair Building Fiber</option>
					<option>H20 Mop X5</option>
                    <option>Hair Straightner</option>
                    <option>Epilator</option>
					<option>Hair Dryer</option>
                    <option>Veet For Men</option>
					<option>Slap Chop</option>
                    <option>Handy Massager</option>
                    <option>Ab Rocket</option> 
					<option>Ab Rocket Twister</option>
                    <option>English Guru</option>
                    <option>Magic Pen 2Gb</option>
                    <option>Magic Pen 4Gb</option>
					<option>Perfect Shaper</option>
					<option>Ionic White</option>
                    <option>Soft Fair</option>
                    <option>Men Power</option>
					<option>Power Prash</option>
                    <option>Breast Enlargement</option>
                    <option>Lady Secret Cream</option>
                    <option>In Styler</option>
					<option>Electric Beauty Threader</option>
					<option>Tummy Fit</option>
					<option>Pops A Dent</option>
					<option>Other</option>
					</select>                </td>
              </tr>
              <tr>
                <td width="180"></td>
                <td width="220"><div id="mainsubcat">	</div></td>
              </tr>
              <tr>
                <td height="35" align="left" valign="middle" class="text13g">Other</td>
                <td height="35" align="left" valign="middle"><input style="height: 30px;" type="text" name="other" class="textfield" /></td>
              </tr>
              <tr>
                <td width="180" height="200" align="left" valign="middle" class="text13g">Any Comments:</td>
                <td width="220" height="200" align="left" valign="middle"><textarea name="comments" data-maxsize="100" data-output="status1" wrap="virtual" class="textarea"></textarea>
                <br /><div id="status1" style="width:200px; font-weight:bold; text-align:right"></div></td>
              </tr>
              <tr>
                <td width="180" height="35"></td>
                <td width="220" height="35" align="left" valign="middle">
                	<table width="220" cellpadding="0" cellspacing="0" border="0">
                    	<tr><td width="110" align="left" valign="middle"><input type="submit" name="btnSubmit" value="Place Order" class="btn-cat" /></td>
                        <td width="110" align="center" valign="middle"><input type="reset" name="reset" value="Reset" class="btn-cat" /></td>
                        </tr>
                    </table>
                </td>
              </tr>
            </table>
            </form></td>
			
            <td align="center" valign="top"><table width="320" border="0" cellpadding="0" cellspacing="0" bgcolor="#efefef">
              <tr>
                <td height="40" align="center" valign="middle" class="prod">Contact Us</td>
              </tr>
                           <tr>
                <td height="30" align="center" valign="middle" class="text15">Call Or Sms For Offline Order</td>
              </tr>
              <tr>
                <td height="45" align="center" valign="middle" class="text15"><b><span class="red"><font color="#">0333-1619220&nbsp;&nbsp;&nbsp;0300-7986016<br />
                  0347-7245206&nbsp;&nbsp;&nbsp;0316-8086016</font></span></b>
				  <ul>
                                       <span>&gt;&gt;</span>  About Product Price<br>
                                      <span>&gt;&gt;</span>  About Product Results<br>
                                        <span>&gt;&gt;</span>  You Can Track Order<br>
                                     <span>&gt;&gt;</span>  Place Order <br>
                                    </ul></td>
              </tr>
            
             
            </table></td>
          </tr>
          </table></td>
      </tr>
      </table></td>
	  </tr>
 <br>				</div>
				 <div class="col-md-6 ab_pic_w3ls_text_info">


				 </div>
				  <div class="clearfix"></div>
			</div>    
            <!--<div class="banner_bottom_agile_info_inner_w3ls">
    	           <div class="col-md-6 wthree_banner_bottom_grid_three_left1 grid">
						<figure class="effect-roxy">
							<img src="images/bottom1.jpg" alt=" " class="img-responsive" />
							<figcaption>
								<h3><span>F</span>all Ahead</h3>
								<p>New Arrivals</p>
							</figcaption>			
						</figure>
					</div>
					 <div class="col-md-6 wthree_banner_bottom_grid_three_left1 grid">
						<figure class="effect-roxy">
							<img src="images/bottom2.jpg" alt=" " class="img-responsive" />
							<figcaption>
								<h3><span>F</span>all Ahead</h3>
								<p>New Arrivals</p>
							</figcaption>			
						</figure>
					</div>
					<div class="clearfix"></div>
		    </div> -->
		 </div> 
    </div>
	<!-- team -->
<!--<div class="banner_bottom_agile_info team">
	<div class="container">
	            <h3 class="wthree_text_info">Our Team <span>Members</span></h3>
			<div class="inner_w3l_agile_grids">
					<div class="col-md-3 team-grids">
						<div class="thumbnail team-w3agile">
							<img src="images/t1.jpg" class="img-responsive" alt="">
							<div class="social-icons team-icons right-w3l fotw33">
							<div class="caption">
								<h4>Joanna Vilken</h4>
								<p>Add Short Description</p>						
							</div>
								<ul class="social-nav model-3d-0 footer-social w3_agile_social two">
															<li><a href="#" class="facebook">
																  <div class="front"><i class="fa fa-facebook" aria-hidden="true"></i></div>
																  <div class="back"><i class="fa fa-facebook" aria-hidden="true"></i></div></a></li>
															<li><a href="#" class="twitter"> 
																  <div class="front"><i class="fa fa-twitter" aria-hidden="true"></i></div>
																  <div class="back"><i class="fa fa-twitter" aria-hidden="true"></i></div></a></li>
															<li><a href="#" class="instagram">
																  <div class="front"><i class="fa fa-instagram" aria-hidden="true"></i></div>
																  <div class="back"><i class="fa fa-instagram" aria-hidden="true"></i></div></a></li>
															<li><a href="#" class="pinterest">
																  <div class="front"><i class="fa fa-linkedin" aria-hidden="true"></i></div>
																  <div class="back"><i class="fa fa-linkedin" aria-hidden="true"></i></div></a></li>
														</ul>
							          </div>
						     </div>
			         	</div>
						<div class="col-md-3 team-grids">
						<div class="thumbnail team-w3agile">
							<img src="images/t2.jpg" class="img-responsive" alt="">
							<div class="social-icons team-icons right-w3l fotw33">
							<div class="caption">
								<h4>Anika Mollik</h4>
								<p>Add Short Description</p>						
							</div>
								<ul class="social-nav model-3d-0 footer-social w3_agile_social two">
															<li><a href="#" class="facebook">
																  <div class="front"><i class="fa fa-facebook" aria-hidden="true"></i></div>
																  <div class="back"><i class="fa fa-facebook" aria-hidden="true"></i></div></a></li>
															<li><a href="#" class="twitter"> 
																  <div class="front"><i class="fa fa-twitter" aria-hidden="true"></i></div>
																  <div class="back"><i class="fa fa-twitter" aria-hidden="true"></i></div></a></li>
															<li><a href="#" class="instagram">
																  <div class="front"><i class="fa fa-instagram" aria-hidden="true"></i></div>
																  <div class="back"><i class="fa fa-instagram" aria-hidden="true"></i></div></a></li>
															<li><a href="#" class="pinterest">
																  <div class="front"><i class="fa fa-linkedin" aria-hidden="true"></i></div>
																  <div class="back"><i class="fa fa-linkedin" aria-hidden="true"></i></div></a></li>
														</ul>
							          </div>
						     </div>
			         	</div>
						<div class="col-md-3 team-grids">
						<div class="thumbnail team-w3agile">
							<img src="images/t3.jpg" class="img-responsive" alt="">
							<div class="social-icons team-icons right-w3l fotw33">
							<div class="caption">
								<h4>Megali Deo</h4>
								<p>Add Short Description</p>						
							</div>
								<ul class="social-nav model-3d-0 footer-social w3_agile_social two">
															<li><a href="#" class="facebook">
																  <div class="front"><i class="fa fa-facebook" aria-hidden="true"></i></div>
																  <div class="back"><i class="fa fa-facebook" aria-hidden="true"></i></div></a></li>
															<li><a href="#" class="twitter"> 
																  <div class="front"><i class="fa fa-twitter" aria-hidden="true"></i></div>
																  <div class="back"><i class="fa fa-twitter" aria-hidden="true"></i></div></a></li>
															<li><a href="#" class="instagram">
																  <div class="front"><i class="fa fa-instagram" aria-hidden="true"></i></div>
																  <div class="back"><i class="fa fa-instagram" aria-hidden="true"></i></div></a></li>
															<li><a href="#" class="pinterest">
																  <div class="front"><i class="fa fa-linkedin" aria-hidden="true"></i></div>
																  <div class="back"><i class="fa fa-linkedin" aria-hidden="true"></i></div></a></li>
														</ul>
							          </div>
						     </div>
			         	</div>
						<div class="col-md-3 team-grids">
						<div class="thumbnail team-w3agile">
							<img src="images/t4.jpg" class="img-responsive" alt="">
							<div class="social-icons team-icons right-w3l fotw33">
							<div class="caption">
								<h4>Retas Word</h4>
								<p>Add Short Description</p>						
							</div>
								<ul class="social-nav model-3d-0 footer-social w3_agile_social two">
															<li><a href="#" class="facebook">
																  <div class="front"><i class="fa fa-facebook" aria-hidden="true"></i></div>
																  <div class="back"><i class="fa fa-facebook" aria-hidden="true"></i></div></a></li>
															<li><a href="#" class="twitter"> 
																  <div class="front"><i class="fa fa-twitter" aria-hidden="true"></i></div>
																  <div class="back"><i class="fa fa-twitter" aria-hidden="true"></i></div></a></li>
															<li><a href="#" class="instagram">
																  <div class="front"><i class="fa fa-instagram" aria-hidden="true"></i></div>
																  <div class="back"><i class="fa fa-instagram" aria-hidden="true"></i></div></a></li>
															<li><a href="#" class="pinterest">
																  <div class="front"><i class="fa fa-linkedin" aria-hidden="true"></i></div>
																  <div class="back"><i class="fa fa-linkedin" aria-hidden="true"></i></div></a></li>
														</ul>
							          </div>
						     </div>
			         	</div>
					<div class="clearfix"> </div>
				</div>
	       </div>
		</div>-->
<!-- //team -->

	<!-- schedule-bottom -->
	<!--<div class="schedule-bottom">
		<div class="col-md-6 agileinfo_schedule_bottom_left">
			<img src="images/mid.jpg" alt=" " class="img-responsive" />
		</div>
		<div class="col-md-6 agileits_schedule_bottom_right">
			<div class="w3ls_schedule_bottom_right_grid">
				<h3>Save up to <span>50%</span> in this week</h3>
				<p>Suspendisse varius turpis efficitur erat laoreet dapibus. 
					Mauris sollicitudin scelerisque commodo.Nunc dapibus mauris sed metus finibus posuere.</p>
				<div class="col-md-4 w3l_schedule_bottom_right_grid1">
					<i class="fa fa-user-o" aria-hidden="true"></i>
					<h4>Customers</h4>
					<h5 class="counter">653</h5>
				</div>
				<div class="col-md-4 w3l_schedule_bottom_right_grid1">
					<i class="fa fa-calendar-o" aria-hidden="true"></i>
					<h4>Events</h4>
					<h5 class="counter">823</h5>
				</div>
				<div class="col-md-4 w3l_schedule_bottom_right_grid1">
					<i class="fa fa-shield" aria-hidden="true"></i>
					<h4>Awards</h4>
					<h5 class="counter">45</h5>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
		<div class="clearfix"> </div>
	</div>-->
<!-- //schedule-bottom -->
  <!-- banner-bootom-w3-agileits -->
	<!--<div class="banner-bootom-w3-agileits">
	   <div class="container">
	     <h3 class="wthree_text_info">What's <span>Trending</span></h3>
	
		<div class="col-md-5 bb-grids bb-left-agileits-w3layouts">
			<a href="women.html">
			   <div class="bb-left-agileits-w3layouts-inner grid">
					<figure class="effect-roxy">
							<img src="images/bb1.jpg" alt=" " class="img-responsive" />
							<figcaption>
								<h3><span>S</span>ale </h3>
								<p>Upto 55%</p>
							</figcaption>			
						</figure>
			    </div>
			</a>
		</div>
		<div class="col-md-7 bb-grids bb-middle-agileits-w3layouts">
		       <div class="bb-middle-agileits-w3layouts grid">
			           <figure class="effect-roxy">
							<img src="images/bottom3.jpg" alt=" " class="img-responsive" />
							<figcaption>
								<h3><span>S</span>ale </h3>
								<p>Upto 55%</p>
							</figcaption>			
						</figure>
		        </div>
		      <div class="bb-middle-agileits-w3layouts forth grid">
						<figure class="effect-roxy">
							<img src="images/bottom4.jpg" alt=" " class="img-responsive">
							<figcaption>
								<h3><span>S</span>ale </h3>
								<p>Upto 65%</p>
							</figcaption>		
						</figure>
					</div>
		<div class="clearfix"></div>
	</div>
    </div>
</div>-->
<!--/grids-->
     <!-- <div class="agile_last_double_sectionw3ls">
            <div class="col-md-6 multi-gd-img multi-gd-text ">
					<a href="womens.html"><img src="images/bot_1.jpg" alt=" "><h4>Flat <span>50%</span> offer</h4></a>
					
			</div>
			 <div class="col-md-6 multi-gd-img multi-gd-text ">
					<a href="womens.html"><img src="images/bot_2.jpg" alt=" "><h4>Flat <span>50%</span> offer</h4></a>
			</div>
			<div class="clearfix"></div>
	   </div>		-->					
<!--/grids-->
	<!-- /we-offer -->
		<!--<div class="sale-w3ls">
			<div class="container">
				<h6>We Offer Flat <span>40%</span> Discount</h6>
 
				<a class="hvr-outline-out button2" href="single.html">Shop Now </a>
			</div>
		</div>-->
	<!-- //we-offer -->
<!--/grids-->
<div class="coupons">
		<div class="coupons-grids text-center">
			<div class="w3layouts_mail_grid">
				<div class="col-md-3 w3layouts_mail_grid_left">
					<div class="w3layouts_mail_grid_left1 hvr-radial-out">
						<i class="fa fa-truck" aria-hidden="true"></i>
					</div>
					<div class="w3layouts_mail_grid_left2">
						<h3>FREE SHIPPING</h3>
						<p> We Will Deliver Your Products At Your Door Step With in 24hrs Delivery Time in Major Cities And Other Towns & Cities 48 Hrs. Home Delivery Service Anywhere in Pakistan Service  Charges 200 More Then One Products Home Delivery Free.  </p>
					</div>
				</div>
				<div class="col-md-3 w3layouts_mail_grid_left">
					<div class="w3layouts_mail_grid_left1 hvr-radial-out">
						<i class="fa fa-headphones" aria-hidden="true"></i>
					</div>
					<div class="w3layouts_mail_grid_left2">
						<h3>24/7 SUPPORT</h3>
						<p>Shop Pakistan Online Store. Shoppakistan.pk is a convenient place to purchase Health, Fitness, Home products and Sexual from Shop Pakistan. You can buy online, chat, or call (0300-7986016), 24/7 at any time.</p>
					</div>
				</div>
				<div class="col-md-3 w3layouts_mail_grid_left">
					<div class="w3layouts_mail_grid_left1 hvr-radial-out">
						<i class="fa fa-shopping-bag" aria-hidden="true"></i>
					</div>
					<div class="w3layouts_mail_grid_left2">
						<h3>MONEY BACK GUARANTEE</h3>
						<p>We offer a 75% money-back guarantee within 5 days of payment on all Producsts.If a Buyer is not satisfied with a product or service, a refund will be made.</p>
					</div>
				</div>
					<div class="col-md-3 w3layouts_mail_grid_left">
					<div class="w3layouts_mail_grid_left1 hvr-radial-out">
						<i class="fa fa-gift" aria-hidden="true"></i>
					</div>
					<div class="w3layouts_mail_grid_left2">
						<h3>DISCOUNT GIFT COUPONS</h3>
						<p>If a person/customer regularly purchase our Product.We offer 10% discount when he purchased the other products from our Online Store Shop Pakistan</p>
					</div>
				</div>
				<div class="clearfix"> </div>
			</div>

		</div>
</div>
<!--grids-->
<!-- footer -->
<div class="footer">
	<div class="footer_agile_inner_info_w3l">
		<div class="col-md-3 footer-left">
			<h2><a href="index.html"><span>S</span>hop Pakistan </a></h2>
			<p>As Seen On TV Products is really a generic name attached to items that are advertised on television, either in 30 minute infomercial spots, or in 30-second commercials. Famously, these items sell for $19.95 (plus shipping and handling, of course)</p>
			<ul class="social-nav model-3d-0 footer-social w3_agile_social two">
															<li><a href="#" class="facebook">
																  <div class="front"><i class="fa fa-facebook" aria-hidden="true"></i></div>
																  <div class="back"><i class="fa fa-facebook" aria-hidden="true"></i></div></a></li>
															<li><a href="#" class="twitter"> 
																  <div class="front"><i class="fa fa-twitter" aria-hidden="true"></i></div>
																  <div class="back"><i class="fa fa-twitter" aria-hidden="true"></i></div></a></li>
															<li><a href="#" class="instagram">
																  <div class="front"><i class="fa fa-instagram" aria-hidden="true"></i></div>
																  <div class="back"><i class="fa fa-instagram" aria-hidden="true"></i></div></a></li>
															<li><a href="#" class="pinterest">
																  <div class="front"><i class="fa fa-linkedin" aria-hidden="true"></i></div>
																  <div class="back"><i class="fa fa-linkedin" aria-hidden="true"></i></div></a></li>
														</ul>
		</div>
		<div class="col-md-9 footer-right">
			<div class="sign-grds">
				<div class="col-md-4 sign-gd">
					<h4>Our <span>Information</span> </h4>
					<ul>
						<li><a href="index.html">Home</a></li>
						<li><a href="mens.html">Men's</a></li>
						<li><a href="womens.html">Women's </a></li>
						<li><a href="about.html">About</a></li>
						<li><a href="typography.html">Health & Fitness</a></li>
						<li><a href="contact.html">Contact</a></li>
					</ul>
				</div>
				
				<div class="col-md-5 sign-gd-two">
					<h4>Store <span>Information</span></h4>
					<div class="w3-address">
						<div class="w3-address-grid">
							<div class="w3-address-left">
								<i class="fa fa-phone" aria-hidden="true"></i>
							</div>
							<div class="w3-address-right">
								<h6>Phone Number</h6>
								<p>+92 300 79 86 016</p>
							</div>
							<div class="clearfix"> </div>
						</div>
						<div class="w3-address-grid">
							<div class="w3-address-left">
								<i class="fa fa-envelope" aria-hidden="true"></i>
							</div>
							<div class="w3-address-right">
								<h6>Email Address</h6>
								<p>Email :<a href="#">order@shoppakistan.pk</a></p>
							</div>
							<div class="clearfix"> </div>
						</div>
						<div class="w3-address-grid">
							<div class="w3-address-left">
								<i class="fa fa-map-marker" aria-hidden="true"></i>
							</div>
							<div class="w3-address-right">
								<h6>Location</h6>
								<p>Islamabad Pakistan,. 
								
								</p>
							</div>
							<div class="clearfix"> </div>
						</div>
					</div>
				</div>
				<div class="col-md-3 sign-gd flickr-post">
					<h4>Flickr <span>Posts</span></h4>
					<ul>
						<li><a href="single.html"><img src="images/t1.jpg" alt=" " class="img-responsive" /></a></li>
						<li><a href="single.html"><img src="images/t2.jpg" alt=" " class="img-responsive" /></a></li>
						<li><a href="single.html"><img src="images/t3.jpg" alt=" " class="img-responsive" /></a></li>
						<li><a href="single.html"><img src="images/t4.jpg" alt=" " class="img-responsive" /></a></li>
						<li><a href="single.html"><img src="images/t1.jpg" alt=" " class="img-responsive" /></a></li>
						<li><a href="single.html"><img src="images/t2.jpg" alt=" " class="img-responsive" /></a></li>
						<li><a href="single.html"><img src="images/t3.jpg" alt=" " class="img-responsive" /></a></li>
						<li><a href="single.html"><img src="images/t2.jpg" alt=" " class="img-responsive" /></a></li>
						<li><a href="single.html"><img src="images/t4.jpg" alt=" " class="img-responsive" /></a></li>
					</ul>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
		<div class="clearfix"></div>
			<div class="agile_newsletter_footer">
					<div class="col-sm-6 newsleft">
				<h3>SIGN UP FOR NEWSLETTER !</h3>
			</div>
			<div class="col-sm-6 newsright">
				<form action="#" method="post">
					<input type="email" placeholder="Enter your email..." name="email" required="">
					<input type="submit" value="Submit">
				</form>
			</div>

		<div class="clearfix"></div>
	</div>
		<p class="copy-right">&copy 2017 Shop Pakistan. All rights reserved | Design by <a href="">Shop Pakistan</a></p>
	</div>
</div>
<!-- //footer -->

<!-- login -->
			<div class="modal fade" id="myModal4" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
				<div class="modal-dialog" role="document">
					<div class="modal-content modal-info">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>						
						</div>
						<div class="modal-body modal-spa">
							<div class="login-grids">
								<div class="login">
									<div class="login-bottom">
										<h3>Sign up for free</h3>
										<form>
											<div class="sign-up">
												<h4>Email :</h4>
												<input type="text" value="Type here" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Type here';}" required="">	
											</div>
											<div class="sign-up">
												<h4>Password :</h4>
												<input type="password" value="Password" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Password';}" required="">
												
											</div>
											<div class="sign-up">
												<h4>Re-type Password :</h4>
												<input type="password" value="Password" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Password';}" required="">
												
											</div>
											<div class="sign-up">
												<input type="submit" value="REGISTER NOW" >
											</div>
											
										</form>
									</div>
									<div class="login-right">
										<h3>Sign in with your account</h3>
										<form>
											<div class="sign-in">
												<h4>Email :</h4>
												<input type="text" value="Type here" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Type here';}" required="">	
											</div>
											<div class="sign-in">
												<h4>Password :</h4>
												<input type="password" value="Password" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Password';}" required="">
												<a href="#">Forgot password?</a>
											</div>
											<div class="single-bottom">
												<input type="checkbox"  id="brand" value="">
												<label for="brand"><span></span>Remember Me.</label>
											</div>
											<div class="sign-in">
												<input type="submit" value="SIGNIN" >
											</div>
										</form>
									</div>
									<div class="clearfix"></div>
								</div>
								<p>By logging in you agree to our <a href="#">Terms and Conditions</a> and <a href="#">Privacy Policy</a></p>
							</div>
						</div>
					</div>
				</div>
			</div>
<!-- //login -->
<a href="#home" class="scroll" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>

<!-- js -->
<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
<!-- //js -->
<script src="js/modernizr.custom.js"></script>
	<!-- Custom-JavaScript-File-Links --> 
	<!-- cart-js -->
	<script src="js/minicart.min.js"></script>
<script>
	// Mini Cart
	paypal.minicart.render({
		action: '#'
	});

	if (~window.location.search.indexOf('reset=true')) {
		paypal.minicart.reset();
	}
</script>

	<!-- //cart-js --> 
<!-- script for responsive tabs -->						
<script src="js/easy-responsive-tabs.js"></script>
<script>
	$(document).ready(function () {
	$('#horizontalTab').easyResponsiveTabs({
	type: 'default', //Types: default, vertical, accordion           
	width: 'auto', //auto or any width like 600px
	fit: true,   // 100% fit in a container
	closed: 'accordion', // Start closed if in accordion view
	activate: function(event) { // Callback function if tab is switched
	var $tab = $(this);
	var $info = $('#tabInfo');
	var $name = $('span', $info);
	$name.text($tab.text());
	$info.show();
	}
	});
	$('#verticalTab').easyResponsiveTabs({
	type: 'vertical',
	width: 'auto',
	fit: true
	});
	});
</script>
<!-- //script for responsive tabs -->		
<!-- stats -->
	<script src="js/jquery.waypoints.min.js"></script>
	<script src="js/jquery.countup.js"></script>
	<script>
		$('.counter').countUp();
	</script>
<!-- //stats -->
<!-- start-smoth-scrolling -->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/jquery.easing.min.js"></script>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$(".scroll").click(function(event){		
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
		});
	});
</script>
<!-- here stars scrolling icon -->
	<script type="text/javascript">
		$(document).ready(function() {
			/*
				var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
				};
			*/
								
			$().UItoTop({ easingType: 'easeOutQuart' });
								
			});
	</script>
<!-- //here ends scrolling icon -->


<!-- for bootstrap working -->
<script type="text/javascript" src="js/bootstrap.js"></script>
</body>
</html>
