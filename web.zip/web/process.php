<?php

$name     = $_REQUEST['txtName'];
$address  = $_REQUEST['txtAddress'];
$city     = $_REQUEST['txtCity'];
$country  = $_REQUEST['country'];
$contact  = $_REQUEST['txtMobile'];
$contact2 = $_REQUEST['txtMobile2'];
$email    = $_REQUEST['txtEmail'];
$product  = $_REQUEST['product'];
$other  = $_REQUEST['other'];
$comments = $_REQUEST['comments'];
$ip_address = getRealIpAddr();
function getRealIpAddr()
{
    if (!empty($_SERVER['HTTP_CLIENT_IP']))   //check ip from share internet
    {
      $ip=$_SERVER['HTTP_CLIENT_IP'];
    }
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))   //to check ip is pass from proxy
    {
      $ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
    }
    else
    {
      $ip=$_SERVER['REMOTE_ADDR'];
    }
    return $ip;
}

$to       = "order@shoppakistan.pk";
$subject  = "Order mts-pk";
$message  = "Name: " . $name . "<br><br> Address: " . $address . "<br><br> City: " . $city . "<br><br> Country: " . $country . "<br><br> Contact: " . $contact . "<br><br> Contact2: " . $contact2 . "<br><br>  Email: " . $email . 
"<br><br> Product is: " . $product . "<br><br> Other: " . $other . "<br><br> Comments: " . $comments . "<br><br> IP Address: " . $ip_address; 



$from     = $email;

$headers  = "MIME-Version: 1.0" . "\n";
$headers .= "Content-type:text/html;charset=iso-8859-1" . "\n";
$headers .= "From: $from" . "\n";

@mail ($to, $subject, $message, $headers);

header ("Location: order-submit.php");



?>



	
